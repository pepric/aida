/**
 * Machine Learning Execution and Interactive Plotting Utilities.
 *
 * Provides functions for preparing parameters, executing Machine Learning training/evaluation
 * jobs (Classification, Regression, Clustering) via AJAX/Python scripts, calculating statistical
 * estimators, rendering Plotly charts (trend, histogram, scatterplot), and managing UI tabs.
 *
 * @package    AIDA
 * @subpackage JS\MachineLearning
 * @author     Giuseppe Riccio
 * @version    1.1.0
 */
 
 
/**
 * Triggers offline execution for Machine Learning plot generation.
 *
 * @param {Event} e Event object.
 */ 
function run_plot_offline(e){
	var ny = parseInt($("#n_ypar").val());
	var system = document.getElementById("hktm_source").value;
	var plot = $("#plot_type").val()

	var username = document.getElementById("session-user").innerHTML    
	var stats = $("#stats_enable").val();
  	var stats_list = get_stats_list()
	//prepare_data
	out = prepare_data(ny, plot);
	params = out[0];
	ny = out[2]
	params.isonline = 0
	params.plot_type = plot
	params.stats = stats
	params.stats_list = JSON.stringify(stats_list)
	params.url = window.location.host
	labels = out[1];
	params.labels = labels

	params.model =	document.getElementById("model").value,
	params.tech =	document.getElementById("technique").value,
	params.model_param=JSON.stringify(FormDataToJSON(document.getElementById('stats_form'))),
	params.split=document.getElementById("traintest").value,
	params.username = document.getElementById("session-user").innerHTML,			
	params.seed=document.getElementById("splitRandomState").value
  
	if(plot == "histogram"){    
		var binsize = document.getElementById('binsize').value;
		var bintype = $('input[name=bintype]:checked').val();
      	params.binsize = binsize
      	params.bintype = bintype
    }  
  
	pyscript = "scripts/get_data.py"; 
  	// perform offline analysis
	$.ajax({
		type: "POST",
		url: pyscript,
		data: params ,
		dataType: "html",
		cache: false,
		async:'asynchronous'
	});
	e.preventDefault();
	

}


/**
 * Triggers online execution of Machine Learning training or prediction via Python AJAX calls.
 *
 * @param {Event} e Event object.
 */
function run_py(e) {
	var ny = parseInt($("#n_ypar").val());
	var system = document.getElementById("hktm_source").value;
	var plot = $("#plot_type").val()	
	var stats = $("#stats_enable").val();	
	var usecase = $("#usecase").val();	
	var go = true
	const tech = $("#technique").val();
	
	if(go==true){
		out = prepare_data(ny, plot);

		params = out[0];
		ny = out[2];
		
		labels = out[1];
		var labels = out[1];
		params.labels = labels;
		pyscript = "scripts/get_data.py";
		
		params.isonline = 1
		params.tech = tech
		if(tech=="cluster"){
			params.plot_type="trend"
		}
		else
		{
			params.plot_type="scatter"
		}
		console.log(params)
		var op = "Machine Learning";
		$.ajax({
			
			type: "POST",
			url: pyscript,
			data: params ,
		dataType: "html",
			cache: false,
			async:'asynchronous',
			beforeSend: function(){
				// Show loader image container
				$("#loader").show();
				window.document.body.scrollTop = 0;
				window.document.documentElement.scrollTop = 0;
			},
			success: function(returndata){
				results = JSON.parse(returndata)
				//console.log(results)
				document.getElementById("modal-labels").value = labels
				document.getElementById("modal-tstart").value = params['tstart']     
				document.getElementById("modal-tstop").value = params['tend']
				document.getElementById("modal-pid").value = params['pid']

				//operation name
				var op2hist
				//parameters
				var l2hist = labels.slice(1).join(",")
				
				var errstatus = results['errstatus']
				var warningstatus = results['warningstatus']
				var datastatus = results['datastatus']
				var infostatus = results['infostatus']
				
				
				if (errstatus == 1){
					alert(results['msg']);
					document.getElementById("plot_container").style=("display : none");
				}
				else {
					if (warningstatus == 1  ||  datastatus == 1){
						alert(results['msg']);
						if (datastatus == 1){
							document.getElementById("plot_container").style=("display : none");
							$("#loader").hide();
						}
						
					}
					if (infostatus == 1){
						alert(results['infomsg']);
						$("#loader").hide();
					}
					
					if (datastatus == 0){
						var numstatus = 0
						//check if label are integers in classification exp
						if(tech=="classifier"){
							labels_arr = results['x']
							var i = 0, len = labels_arr.length;
							var isnum
							//var num_of_int = 0
							var nummsg = ""
							while (i < len) {
								curr = labels_arr[i]
								if (typeof curr === 'number') {
									isnum = Number.isInteger(curr)
								}						
								else{
									const num = Number(curr);
									isnum = Number.isInteger(num)
								}
								if(!isnum){
									//num_of_int++
									numstatus = 1
									nummsg = "Error! Labels for a classifier must be only integers. Chosen Label parameter array contains floats or strings."
									break;
								}								
								i++
							}
/* 							if(num_of_int<len){
								numstatus = 1
								nummsg = "Error! Labels for a classifier must be only integers. Label parameter contains floats"
							} */
							
						}		
						if(numstatus == 0){
							op = "Machine Learning";
							n_exp = tech
							display_plot(n_exp)

	/*						var dom = document.getElementById('chartContainer');
							var modebar = document.getElementsByClassName("modebar")[0]
							if(typeof modebar != 'undefined'){
								modebar.style='display:none;';
							} */
							
							//console.log(stats_list)
							stat_results=calculate_stats(returndata, ny, tech, stats, labels)
						}
						else{
							alert(nummsg);
							document.getElementById("plot_container").style=("display : none");							
							
						}
					f = labels.slice(1).join(",")
					if(tech == "cluster"){
						l = null
						t = "Clustering"
					}
					else {
						l = params.labels[0]
						t = String(tech).charAt(0).toUpperCase() + String(tech).slice(1)
					}
					
					//Store data in history
					/*update history*/
					out_hist = {
						"source" : params['source'],
						"dates range" : "["+params['tstart']+", "+params['tend']+"]",
						"ML technique" : t,
						"model" : document.getElementById("model").value,
						"label" : l,
						"features" : f
					}
					config_hist = {
						"model paramaters" : FormDataToJSON(document.getElementById('stats_form')),
						"split (Train/Test)" : document.getElementById("traintest").value+"/"+(100-document.getElementById("traintest").value),
						"random seed" : document.getElementById("splitRandomState").value
					}

					$.ajax({
						type: "POST",
						url: "functions.php",
						data: {
							action: "update_history",
							username : document.getElementById("session-user").innerHTML,
							operation : op,
							infile :	"NA",
							out	: JSON.stringify(out_hist),
							//config : JSON.stringify(params)
							config : JSON.stringify(config_hist)
							},
						error : function (obj, textstatus) {
							alert("Impossible to store the operation in History")
							}
						})
					}

				
				}
			
			},
			complete:function(data){
				//display tabs
				//display_results(plot, stats);
				// Hide loader image container
				$("#loader").hide();
				
			}
		});
		e.preventDefault();	
	}
};	

/**
 * Collects form inputs and builds parameter payload and label arrays for ML jobs.
 *
 * @param {number} ny Number of Y parameters.
 * @param {string} plot Plot type or ML model context.
 * @returns {Array} Array containing [params, labels, ny].
 */
function prepare_data(ny,plot){
	var source_settings ={
		"NISP" : {"nrows" : 4, "ncols" : 4},
		"NIR" : {"nrows" : 4, "ncols" : 4},
		"SIR" : {"nrows" : 4, "ncols" : 4},
		"VIS" : {"nrows" : 6, "ncols" : 6}
	}
	var adu_flag, alt_tbl_div,  coeff_arr
	var first_coeff = "None"
	var y0sys = $("#y0-sys").val();

	//extra parameters  
  	var extra={}
    $.each($('input', '#y0_extra_filters'),function(){
        extra[$(this).attr('id')] = $(this).val();
    });
    $.each($('input', '#x_extra_filters'),function(){
        extra[$(this).attr('id')] = $(this).val();
    });
    $.each($('textarea', '#y0_extra_filters'),function(){
        extra[$(this).attr('id')] = $(this).val();
    });
    $.each($('textarea', '#x_extra_filters'),function(){
        extra[$(this).attr('id')] = $(this).val();
    });  
	// parameter type (current/statistics/voltage etc), if present
	alt_tbl = set_alt_tbl("y0")
  
	//checked box ADU/CALIBRATED, if present 
	adu_flag = set_adu("y0")
	var source = $("#hktm_source").val()
    var usecase = $("#usecase").val()
	var params = {
		'plot_type' : plot,
		'source': $("#hktm_source").val(),
		'ysys0' : y0sys,
		'ypar0' : $("#y0-params").val(),
		'tstart' : $("#tstart").val(),
		'tend' : $("#tend").val(),
		'user' : document.getElementById("session-user").innerHTML,
		'usecase' : $("#usecase").val(),
		'yic0' : $("#y0-ic").val(),
		'ytbl0' : alt_tbl,
		'yadu0' : adu_flag,
		'pid' : $("#pid").val(),
	}
	params.yval0 = $("#y0-values").val();


	var toduplicate = {}
	var det = $("#det-type").val().split(",");
	var ydetector = null
	var det_type_arr = "None"
	params.yrow0 = "None";
	params.ycol0 = "None";
	var dupli_row = false
	var dupli_col = false	
	if(det[1]!="None" && det[1]!=null){
		var yrow = $("#y0-det-row").val()
		var ycol = $("#y0-det-col").val();
		if(yrow != null){
			det_type_arr = det; 
			if(yrow == "all"){
				yrow = 1
				dupli_row = true
			}
			params.yrow0 = yrow;
			
			if(ycol == "all"){
				ycol = 1
				dupli_col = true
			}
			params.ycol0 = ycol;
			ydetector = collect_detectors(det[1], yrow, ycol, "#y0-quadrant")
			params.ydet0 = ydetector;
		}
	}
	if(dupli_row || dupli_col){
		toduplicate.y0 = [dupli_row,dupli_col]
	}
    var order = set_special_param("y0-order")
    var coeff = set_special_param("y0-coeff")
    var group = "None"
    if(source == "SIR"){
		group = set_group(plot,0)
    }
    params.yorder0 = order	
	var coeff2dupli = {}
	coeff_res = set_coeffs(coeff)
	first_coeff = set_1st_coeff(coeff_res[0])
	coeff_arr = coeff_res[1]
	if(!coeff_arr==[]){
		coeff2dupli.y0 = coeff_arr
	}
	params.ycoeff0 = first_coeff
	y0label = build_label("y0",y0sys, params.ypar0, adu_flag, source, usecase, params.yic0, params.yval0, ydetector, order, first_coeff, group)
	// Create x label and add detector info (if any) if scatter plot 
	if (plot == "ml"){
		var xsys = $("#x-sys").val();
		params.xsys = xsys;
		params.xpar = $("#x-params").val();
		params.xval = $("#x-values").val();
      
		alt_tbl = set_alt_tbl("x")
		params.xtbl = alt_tbl;  

		//checked box ADU/CALIBRATED, if present
		adu_flag = set_adu("x")
		params.xadu = adu_flag     
      
		var xdetector = null
		var xic = $("#x-ic").val();
		params.xic = xic;
		params.xcol = "None";
		params.xrow = "None";
		params.xdet = "None";		
 		if(det[0]!="None" && det[0]!=null){
			var xrow = $("#x-det-row").val();
			var xcol = $("#x-det-col").val();
			if(xrow!=null){
				xdetector = collect_detectors(det[0], xrow, xcol, "#x-quadrant");
				params.xcol = xcol;
				params.xrow = xrow;
				params.xdet = xdetector;
			}
		}
        var order = set_special_param("x-order")
        var coeff = set_special_param("x-coeff")
        var group = "None"
        if(source == "SIR"){
			group = set_group(plot,"",true)
        }       
		xlabel = build_label("x", xsys, params.xpar, adu_flag, source, usecase, params.xic, params.xval, xdetector, order,coeff,group)      
	}
	else{
		xlabel = "None"
	}	

	labels = [xlabel, y0label];
	console.log(labels)
	// COLLECT ALL Y PARAMS
	var additional_y_sys = []
	var additional_y_par = [];
	var additional_y_val = [];
	var additional_y_row = [];
	var additional_y_col = [];
	var additional_y_det = [];	
	var additional_y_ic = [];	
	var additional_y_tbl = [];
	var additional_y_adu = []
	var additional_y_order = []
	var additional_y_coeff = []
	for (i=1; i<ny; i++){
		var new_y_sys = $("#y"+i+"-sys").val();
		var new_y_par = $("#y"+i+"-params").val();
		var new_y_ic = $("#y"+i+"-ic").val();
		additional_y_sys.push(new_y_sys);
		additional_y_par.push(new_y_par);
		additional_y_ic.push(new_y_ic);
		var new_y_val = $("#y"+i+"-values").val();  
		additional_y_val.push(new_y_val);
	  
		alt_tbl = set_alt_tbl("y"+i)         
		additional_y_tbl.push(alt_tbl);          

		//checked box ADU/CALIBRATED, if present
		adu_flag = set_adu("y"+i)
		additional_y_adu.push(adu_flag)
		
		var new_ydetector = "None"
		var new_y_row = "None";
		var new_y_col = "None";		
		//for forms with detectors

		dupli_row = false
		dupli_col = false
		if(det[i+1]!="None" && det[i+1]!=null){
			new_y_row = $("#y"+i+"-det-row").val();
			new_y_col = $("#y"+i+"-det-col").val();
			if(new_y_row!=null){
				if(new_y_row == "all"){
					new_y_row = 1
					dupli_row = true
				}
				if(new_y_col == "all"){
					new_y_col = 1
					dupli_col = true
				}
				new_ydetector = collect_detectors(det[i+1], new_y_row, new_y_col, "#y"+i+"-quadrant");
			}
		}
		additional_y_row.push(new_y_row);
		additional_y_col.push(new_y_col);
		additional_y_det.push(new_ydetector);				
		if(dupli_row || dupli_col){
			toduplicate["y"+i] = [dupli_row,dupli_col]
		}
		var order = set_special_param("y"+i+"-order")
		var coeff = set_special_param("y"+i+"-coeff")
		coeff_res = set_coeffs(coeff)
		first_coeff = set_1st_coeff(coeff_res[0])
		coeff_arr = coeff_res[1]
		if(!coeff_arr==[]){
			coeff2dupli["y"+i] = coeff_arr
		}            
		additional_y_order.push(order);
		additional_y_coeff.push(first_coeff);
		var group = "None"
		if(source == "SIR"){
			group = set_group(plot,i)
		}

		l = build_label("y"+i, new_y_sys, new_y_par, adu_flag, source, usecase, new_y_ic, new_y_val, new_ydetector, order, first_coeff,group)
		labels.push(l);
		// get additional filters
		 $.each($('input', '#y'+i+'_extra_filters'),function(){
			extra[$(this).attr('id')] = $(this).val();
		 });
		 $.each($('textarea', '#y'+i+'_extra_filters'),function(){
			extra[$(this).attr('id')] = $(this).val();
		 });          
	}

	//duplicate params in case of ALL det row/col
	var ndupli = Object.keys(toduplicate).length
	//var idx0 = ny-1
	for(var i=0; i<ndupli;i++){
		var det_list=[]
		var p2dup = Object.keys(toduplicate)[i]
		var dupl_row = toduplicate[p2dup][0]
		var dupl_col = toduplicate[p2dup][1]
		var maxrow,maxcol
		if(source!="QLA"){
			maxrow = source_settings[source]["nrows"]
			maxcol = source_settings[source]["ncols"]
		}
		else{
			var curr_sys = $("#"+p2dup+"-sys").val();
			var curr_sub = curr_sys.split("-")[0]
			maxrow = source_settings[curr_sub]["nrows"]
			maxcol = source_settings[curr_sub]["ncols"]				
		}
		
		if(dupl_row){
			var r_arr = []
			for(var n=1;n<maxrow+1;n++){r_arr.push(n)}
		}
		else{
			var r_arr = [parseInt($("#"+p2dup+"-det-row").val())]
		}
		if(dupl_col){
			var c_arr = []
			for(var n=1;n<maxcol+1;n++){c_arr.push(n)}
		}
		else{
			var c_arr = [parseInt($("#"+p2dup+"-det-col").val())]
		}
		r_arr.forEach(function(a1){
		  c_arr.forEach(function(a2){
			det_list.push(a1 +"-"+ a2);
		  });
		});			
		
		// get data to duplicate from form
		for(var d=0;d<det_list.length;d++){
			var curr = det_list[d].split("-")
			var idx = parseInt(p2dup.replace("y",""))+1
			var curr_dettype = det[idx]
			var curr_det = collect_detectors(curr_dettype, curr[0], curr[1], "#"+p2dup+"-quadrant");
			var curr_sys = $("#"+p2dup+"-sys").val()
			var curr_par = $("#"+p2dup+"-params").val()
			var curr_adu = set_adu(p2dup)
			var curr_ic = $("#"+p2dup+"-ic").val()
			var curr_val = $("#"+p2dup+"-values").val()
			var curr_order = set_special_param(p2dup+"-order")
			var curr_coeff = set_special_param(p2dup+"-coeff")	

			group = "None"
			if(source == "SIR"){
				group = set_group(plot,idx-1)
			}					
			//build label
			l = build_label(p2dup, curr_sys, curr_par, curr_adu, source, usecase, curr_ic, curr_val, curr_det, curr_order, curr_coeff,group)

			if(!labels.slice(1).includes(l)){
				additional_y_sys.push(curr_sys)
				additional_y_par.push(curr_par)
				additional_y_ic.push(curr_ic)
				additional_y_tbl.push(set_alt_tbl(p2dup))
				additional_y_adu.push(curr_adu)
				additional_y_val.push(curr_val);
				additional_y_order.push(curr_order);
				additional_y_coeff.push(curr_coeff);					
				additional_y_row.push(curr[0])
				additional_y_col.push(curr[1])					
				additional_y_det.push(curr_det)	

				//duplicate extra filters		{y<i>_<extra_name>:<value>}
				 $.each($('input', '#'+p2dup+'_extra_filters'),function(){
					div_id = $(this).attr('id').split('_')[1]
					extra['y'+ny+'_'+div_id] = $(this).val();
				 });
				 $.each($('textarea', '#'+p2dup+'_extra_filters'),function(){
					div_id = $(this).attr('id').split('_')[1]
					extra['y'+ny+'_'+div_id] = $(this).val();
				 });
				//duplicate det_type
				var curr_dt = det_type_arr[idx]
				det_type_arr.push(curr_dt)
				labels.push(l);
				ny = ny +1	
			}
		}
	}
		
	//duplicate params in case of list of coeff (not concurrent with det duplication)
	var cdupli = Object.keys(coeff2dupli)

	for(var i=0; i<cdupli.length;i++){
		p2dup = cdupli[i]
		var coeffs = coeff2dupli[p2dup]
		var idx = parseInt(p2dup.replace("y",""))+1
		//TODO
		var curr_sys = $("#"+p2dup+"-sys").val()
		var curr_par = $("#"+p2dup+"-params").val()
		var curr_ic = $("#"+p2dup+"-ic").val()
		var curr_val = $("#"+p2dup+"-values").val()
		var curr_order = set_special_param(p2dup+"-order")
		var curr_adu = set_adu(p2dup)
		group = "None"
		if(source == "SIR"){
			group = set_group(plot,idx-1)
			console.log(group)
		}			
		coeffs.forEach(function(c){
			//build label
			l = build_label(p2dup, curr_sys, curr_par, "False", source, usecase, curr_ic, curr_val, null, curr_order, c,group)
			if(!labels.slice(1).includes(l)){
				additional_y_sys.push(curr_sys)
				additional_y_par.push(curr_par)
				additional_y_ic.push(curr_ic)
				additional_y_tbl.push(set_alt_tbl(p2dup))
				additional_y_adu.push("False")
				additional_y_val.push(curr_val);
				additional_y_order.push(curr_order);
				additional_y_coeff.push(curr_coeff);					
				labels.push(l);
				ny++
			}			
		});
	}
	
	params.ny = ny
	params.det_type = det_type_arr
	// add to data array
	params.additional_y_sys = additional_y_sys;
	params.additional_y_par = additional_y_par;
	params.additional_y_ic = additional_y_ic;
	params.additional_y_tbl = additional_y_tbl;
	params.additional_y_adu = additional_y_adu;
	params.additional_y_val = additional_y_val;
	params.additional_y_row = additional_y_row;
	params.additional_y_col = additional_y_col;
	params.additional_y_det = additional_y_det;	
	params.additional_y_order = additional_y_order;	
	params.additional_y_coeff = additional_y_coeff;	            
	params.extra = JSON.stringify(extra)

	return [params,labels,ny]
}

/**
 * Gathers configured statistical tool options and parameter values into a structured object.
 *
 * @returns {Object} Structured object containing selected statistical tools and their parameters.
 */
function get_stats_list(){
	var stats_data = {}
	// list of selected stats
	var stats_list = document.getElementById("stats_list").value;
	var list_arr = stats_list.split(",")
	// for each stat
	for (var i=0; i<list_arr.length-1; i++){
		// values from form related to the current stat
		var curr_name = list_arr[i];
		var curr_func = document.getElementById(curr_name).value;
		var divmore = document.getElementById("more-"+curr_name);
		var addmore = parseInt(divmore.getAttribute("addmore"));
		// get number of config rows if addmore = 1
 		if(addmore == 1){
			var nexp = parseInt(document.getElementById("par-hidden-"+curr_name).value);
		} 
		else {
			var nexp = 0;
		}
		// json containing general data about stat parameters
		var valdiv = divmore.value;
		// valdiv = "" implies no additional configuration => store stat name and func
 		if (valdiv==""){
			stats_data[curr_name] = curr_func
		}
		else{
			// params is a json containing all the additional configuration parameters
			var params = {}
			var jsonval = JSON.parse(valdiv);
			// names of config parameters
			var keys = Object.keys(jsonval);
			var npar = keys.length;
			// for each configuration row
			for(var k = 0; k<nexp+1; k++){
				// for each parameter of each row
				for(var j=0; j<npar; j++){
					// general name of parameter from json
					var curr_id = jsonval[keys[j]]['id'];
					// if it is the first row, related divs and params do not have the suffix _0
					var index = "";
					if(k > 0){
						index = "_"+k;
					}
					// get value from form
					var expdiv = document.getElementById("par-others-"+curr_name+"_"+k);
					var expval = $(expdiv).find('#'+curr_id+index).val();						
					// add key, value to params
					params[curr_id+index] = expval;
				}
			}
			// append to output json name of function, list of configuraion parameters and number of parameters for each row
			stats_data [curr_name] = {
				"func" : curr_func,
				"params" : params,
				"npar" : npar
			}
		}
	}

  	return stats_data
}

/**
 * Helper to safely extract value from a form element or return "None".
 *
 * @param {string} divname Target element DOM ID.
 * @returns {string} Formatted parameter value string.
 */
function set_special_param(divname){
    var div = document.getElementById(divname)
    var val = "None"
    if(div != null){
        val = div.value
        if(val == ""){val = "None"}
    }    
    return val
}

/**
 * Parses coefficient range or comma-separated list into numerical array.
 *
 * @param {string} coeff Coefficient value or range string.
 * @returns {Array} Array containing [first_coeff, remaining_coeffs_array].
 */
function set_coeffs(coeff){
	var first_coeff
	var coeff_arr = []
	var isnumeric = !isNaN(coeff) && !isNaN(parseInt(coeff))
	if(isnumeric){
		split_coeff = false
	}
	else{
		split_coeff = true
	}
	//create list of coeff
	if(split_coeff){
		var comma_coeff = coeff.split(",")
		comma_coeff.forEach(function(item){
			var split_item = item.split("-")
			if(split_item.length==2){
				for (var i = parseInt(split_item[0]); i <= parseInt(split_item[1]); i++) {
					if(!coeff_arr.includes(i)){
						coeff_arr.push(i);
					}
				}
			}
			else{
				if(!coeff_arr.includes(parseInt(item))){				
					coeff_arr.push(parseInt(item))
				}
			}
		})
		first_coeff = coeff_arr[0]
	}
	else{
		first_coeff = coeff
	}	
	return [first_coeff, coeff_arr.slice(1)]
}

/**
 * Returns first valid numerical coefficient or "None".
 *
 * @param {number|string} c Input coefficient value.
 * @returns {string|number} Evaluated first coefficient.
 */
function set_1st_coeff(c){
	first_coeff = "None"
	if(!isNaN(c)){
		first_coeff = c
	}	
	return first_coeff
}

/**
 * Retrieves alternate parameter type string from element.
 *
 * @param {string} p Parameter prefix ID.
 * @returns {string} Alternate table type string.
 */
function set_alt_tbl(p){
	var alt_tbl_div = document.getElementById(p+"-partype");
	if(alt_tbl_div == null){
      var alt_tbl = ""
    }
  	else{
      var alt_tbl = alt_tbl_div.value;	  
    }	
	return alt_tbl
}

/**
 * Evaluates ADU/Calibrated checkbox state for a parameter.
 *
 * @param {string} p Parameter prefix ID.
 * @returns {string} "True", "False", or "None".
 */
function set_adu(p){
	var adu_flag
	adu_checked = $('input[name="'+p+'-adu_cal"]')         
	if(adu_checked.length > 0){
		if(adu_checked.prop('checked') == true){
			adu_flag = "True"
		}
		else{
			adu_flag = "False"        
		}
	}
	else{
		adu_flag = "None"
	 }
	return adu_flag
}

/**
 * Returns parameter group for SIR data source.
 *
 * @param {string} plot Plot type string.
 * @param {number|string} i Parameter index.
 * @param {boolean} [isX=false] Whether parameter is X axis.
 * @returns {string} Parameter group string.
 */
function set_group(plot, i, isX=false){
	var group = "None"
	var div = "y"+i+"-partype"
	if(isX){
		div = "x-partype"
	}
	if(plot!="pre-generated"){				
		group = set_special_param(div)
		if(group == "parameters"){
			group = "None"
		}                
	}
	return group
}

/**
 * Fetches parameter axis labels from backend interface.
 *
 * @param {string} adu ADU flag status.
 * @param {string} par Parameter string.
 * @param {string} source Data source.
 * @param {string} origin Data origin.
 * @returns {jqXHR} jQuery AJAX deferred object.
 */
function set_labels(adu, par, source, origin){
  return $.ajax({
    url: 'scripts/cs_interface.py',
    data: {
      action: "set_labels",
      adu	: adu,
      par	: par,
      s		: source,
      o		: origin
    }
  });
}

/**
 * Constructs formatted display label string for a parameter.
 *
 * @param {string} pvar Parameter ID prefix.
 * @param {string} sys Subsystem identifier.
 * @param {string} par Parameter name.
 * @param {string} adu ADU flag status.
 * @param {string} source Data source.
 * @param {string} origin Data origin.
 * @param {string} [ic=null] Subsystem identifier.
 * @param {string} [val=null] Value string.
 * @param {string} [det=null] Detector string.
 * @param {string} [order=null] Polynomial order.
 * @param {string} [coeff=null] Coefficient.
 * @param {string} [group=null] Group string.
 * @returns {string} Formatted label string.
 */
function build_label(pvar, sys, par, adu, source, origin, ic=null, val=null, det=null, order=null, coeff=null, group=null){
  	var label = ""
    var syslabel = sys+"."
	if(source=="VIS" && origin=="science"){
    	syslabel = ""
    }    
	if(det!=null && det!="None"){
		label = syslabel+det+"."+par;
	}
	else{
		label = syslabel+par;
	}
	if(ic!=null){label = ic+"."+label}	
	if(val!=null){label = label+"."+val}
	if(order!="None"){label = label+".order"+order}
	if(coeff!="None"){label = label+".coeff"+coeff}
	if(group!="None"){label = label+"["+group.toUpperCase()+"]"}

	var aduparent = $("#"+pvar+"-adu_check").parent().css('display');
	if(aduparent != "none"){
      switch(adu) {
		  case "True":
			  var units = $("#"+pvar+"-adu_check").find("#units").html()
			  if(units != null && units != ""){
				  var utxt = units
			  }
			  else{
				  var utxt = "no units"
			  }
			  label = label+" ("+utxt+")";

			  break;
		  case "False":
			  label = label+" (ADU)";
			  break;
		  case "None":
			  break;      
      }
    }
	return label
}

/**
 * Prepares parameter payload specifically for NISP instrument data.
 *
 * @param {number} ny Number of Y parameters.
 * @param {string} plot Plot type string.
 * @returns {Array} Array containing [params, labels].
 */
function prepare_nisp_data(ny, plot){
	var y0sys = $("#y0-sys").val();
	var det = $("#det-type").val().split(",");
	if(det[1]!="None"){
		var yrow = $("#y0-det-row").val()
		var ycol = $("#y0-det-col").val();
		var y0sys = $("#y0-sys").val();
	}
	else{
		var yrow = "";
		var ycol = "";
		var y0sys = "";
	}

	// PARAMS FROM FORM
	var params = {
				'plot_type' : plot,
				'ny' : ny,
				'source': $("#hktm_source").val(),
				'ysys0' : y0sys,
				'ypar0' : $("#y0-params").val(),
				'tstart' : $("#tstart").val(),
				'tend' : $("#tend").val(),
				'user' : document.getElementById("session-user").innerHTML,
				'usecase' : $("#usecase").val()
			}
	

	// Store x data if scatter plot
	if ((plot == "scatter") || (plot == "ml")){
		var xsys = $("#x-sys").val();
		params.xsys = xsys;
		params.xpar = $("#x-params").val();
		xlabel = xsys+"."+params.xpar;
	}
	else {
		xlabel = "None"
	}

	// CREATE LABELS FOR PLOT
	y0label = y0sys+"."+params.ypar0;
	labels = [xlabel, y0label];	

	// COLLECT ALL Y PARAMS
	if (ny>1) {
		var additional_y_sys = []
		var additional_y_par = [];
		
		for (i=1; i<ny; i++){
			new_y_sys = $("#y"+i+"-sys").val();
			new_y_par = $("#y"+i+"-params").val();
			
			additional_y_sys.push(new_y_sys);
			additional_y_par.push(new_y_par);
			//update labels
			labels.push(new_y_sys+"."+new_y_par);
		}
		// add to data array
		params.additional_y_sys = additional_y_sys;
		params.additional_y_par = additional_y_par;
	}	
	
	return [params,labels]	
}

/**
 * Formats detector row, col, and quadrant into a single token string.
 *
 * @param {string} det Detector type token.
 * @param {string} row Row index.
 * @param {string} col Column index.
 * @param {string} id Quadrant select element selector ID.
 * @returns {string} Formatted detector string token.
 */
function collect_detectors(det, row, col, id){
	if (det=="DET"){
			var detector = det+"_"+row+col;
	}
	else{
		var quad = $(id).val();
		var detector = det+'_'+row+'-'+col;

		if (quad !== "full"){
			detector = detector + '["'+quad+'"]';
		}
	}
	return detector
}

/**
 * Activates plot container UI tab and adjusts dimensions for rendering.
 *
 * @param {string} name Model or experiment display name.
 */
function display_plot(name){
	document.getElementById('plot_container').style='display:block;';
	var plotdiv = document.getElementById('tab1')
	plotdiv.setAttribute("class", "active");
	var a = plotdiv.getElementsByTagName("a")[0];
	a.innerHTML = document.getElementById('model').value;
	plotdiv.style="display : inline-block";
	//document.getElementById('chartContainer').style='height: 570px; width: 100%; display:block;';
	var plottab = document.getElementById('plot_tab')
	//plottab.style='display:block;';
	plottab.setAttribute("class", "tab-pane active")

}

/**
 * Converts HTML FormElement entries into a plain JavaScript Object.
 *
 * @param {HTMLFormElement} FormElement Target form DOM element.
 * @returns {Object} Key-value pair object of form fields.
 */
function FormDataToJSON(FormElement){    
	var formData = new FormData(FormElement);
	var ConvertedJSON= {};
	for (const [key, value]  of formData.entries())
	{
		ConvertedJSON[key] = value;
	}

	return ConvertedJSON
}

/**
 * Dispatches AJAX request to Python backend to compute ML evaluation metrics and statistics.
 *
 * @param {string} pydata Raw JSON output string from data processing script.
 * @param {number} ny Number of Y parameters.
 * @param {string} plot ML technique identifier.
 * @param {string} stats Statistics mode.
 * @param {Array<string>} labels Parameter label array.
 */
function calculate_stats(pydata, ny, plot, stats, labels){
	var stats_data = {}
	// list of selected stats
	var stats_list = document.getElementById("stats_list").value;
	var list_arr = stats_list.split(",")
	// for each stat
	for (var i=0; i<list_arr.length-1; i++){
		// values from form related to the current stat
		var curr_name = list_arr[i];
		var curr_func = document.getElementById(curr_name).value;
		var divmore = document.getElementById("more-"+curr_name);
		var addmore = parseInt(divmore.getAttribute("addmore"));
		// get number of config rows if addmore = 1
 		if(addmore == 1){
			var nexp = parseInt(document.getElementById("par-hidden-"+curr_name).value);
		} 
		else {
			var nexp = 0;
		}
		
		// json containing general data about stat parameters
		var valdiv = divmore.value;

		// valdiv = "" implies no additional configuration => store stat name and func
 		if (valdiv==""){
			stats_data[curr_name] = curr_func
		}
		else{
			// params is a json containing all the additional configuration parameters
			var params = {}
			var jsonval = JSON.parse(valdiv);
			// names of config parameters
			var keys = Object.keys(jsonval);
			var npar = keys.length;
			// for each configuration row
			for(var k = 0; k<nexp+1; k++){
				// for each parameter of each row
				for(var j=0; j<npar; j++){
					// general name of parameter from json
					var curr_id = jsonval[keys[j]]['id'];
						// if it is the first row, related divs and params do not have the suffix _0
						var index = "";
						if(k > 0){
							index = "_"+k;
						}
						// get value from form
						var expdiv = document.getElementById("par-others-"+curr_name+"_"+k);
						var expval = $(expdiv).find('#'+curr_id+index).val();						
						// add key, value to params
						params[curr_id+index] = expval;
			
			
				}
			
			}
			// append to output json name of function, list of configuration parameters and number of parameters for each row
			stats_data [curr_name] = {
				"func" : curr_func,
				"params" : params,
				"npar" : npar
			}
		}
	}
	

	
	
	// input data for Python/CGI
	datain = {
			"inputdata"	    :	JSON.stringify(JSON.parse(pydata)),
			"stats_config"  :   JSON.stringify(stats_data),
			"ny"		    : 	ny,
			"plot_type"	    :	plot,
			"stats_type"    :	stats,
			"model"		    : 	document.getElementById("model").value,
			"model_param"   :   JSON.stringify(FormDataToJSON(document.getElementById('stats_form'))),
			"split"		    : 	document.getElementById("traintest").value,
			"username"      :   document.getElementById("session-user").innerHTML,			
			"seed"		    : 	document.getElementById("splitRandomState").value
			}

	$.when(
		$.ajax({
			type: "POST",
			url: "scripts/calculate_ml.py",
			data: datain, 
			dataType: "html",
			cache: false,
			async:'asynchronous',
			//success: function(data){
				//store stats results in a hidden div
				//var div = document.getElementById('stats_results');
				//div.innerHTML = data;
				//visualize stats as tables
				//render_stats(data, ny, labels, plot, stats)
				//}
			})
			.done(function(data){
				//store stats results in a hidden div
				var div = document.getElementById('stats_results');
				div.innerHTML = data;
				var results = JSON.parse(data);
				var mlerror = results["mlerror"]
				if (mlerror == 1){
					alert("ERROR! Impossible to perform ML analysis");
					document.getElementById("plot_container").style=("display : none");
				}				
				else{
					//visualize stats as tables
					render_stats(data, ny, labels, plot, stats)
					
					//store data into db for tables
					switch(plot){
					  case "classifier":
						  t = "Classification"
						  break;
					  case "regressor":
						  t = "Regression"
						  break;
					  case "cluster":
						  t = "Clustering"
						  break; 						
					}
					config = {
						"tech" : t,
						"model" : datain['model'],
						"params" : datain['model_param'],
						"split_rate" : datain['split'],
						"seed" : datain['seed']
					}
					var strconf = JSON.stringify(config).replaceAll('"','\\"')//.replaceAll('"',"'")
					statsdata = JSON.parse(data)
					delete statsdata["outputfilename"]
					delete statsdata["modelfilename"]
					delete statsdata["mlerror"]
					delete statsdata["model"]
					c = results['modelfilename'].split("model-")[1].split(".")[0].split("-")
					creation = c[0]+"-"+c[1]+"-"+c[2]+" "+c[3]+":"+c[4]+":"+c[5]
					dbdata = {
						"username" : document.getElementById("session-user").innerHTML,
						"modelfile" : results['modelfilename'],
						"outfile" : results['outputfilename'],
						"source" : document.getElementById("hktm_source").value,
						"creation" : creation,
						"labels" : labels.toString(),
						"ts" : document.getElementById("tstart").value,
						"te" : document.getElementById("tend").value,
						"config" :  strconf,
						"stats" : JSON.stringify(statsdata)
					}
					
					$.ajax({
						type: "POST",
						url: "functions.php",
						data: {
							action: "ml_to_db",
							d : dbdata
							},
						error : function (obj, textstatus) {
							alert("Impossible to store the experiment into DB")
							}
					})
										


				
				}
			})
			.fail(function(obj, textstatus) {
							alert("Some error occurred with your model configuration")
							})
		) 
	}

/**
 * Parses Python statistics output and renders HTML tables and download buttons.
 *
 * @param {string} pydata JSON payload from backend script.
 * @param {number} ny Number of Y parameters.
 * @param {Array<string>} labels Parameter label array.
 * @param {string} plot ML technique identifier.
 * @param {string} stats Statistics mode identifier.
 */
function render_stats(pydata, ny, labels, plot, stats){
/* 	try { */
	    var results = JSON.parse(pydata);



	    var parent = document.getElementById("plot_stats");
	    parent.style="display : flex; flex-wrap : wrap";
	    parent.innerHTML = "";
	    ks = Object.keys(results)
	    
	    // create stats div
/* 	    if((plot == "scatter") || (plot == "ml")){
		    var node = document.createElement("div");
		    node.setAttribute("class", "col-md-12");
		    node.setAttribute("style", "font-size:20px; font-weight:bold");
		    node.innerHTML="DATASET 1"
		    parent.appendChild(node)
	    } */

	    // x stats if present
	    if (labels[0] != "null.null" && labels[0] != "undefined.undefined"){
		    xname = labels[0];
		    xdata = results.x_stats;
		    create_stats_table(xdata, xname, parent, "x_stats");
	    }

		console.log(results)
	    if (results.outputfilename != "None"){

			console.log(results)
    //    	document.getElementById('plot_container').innerHTML += document.write("<a href=\"" + results.outputfilename + "\"><p>output file</p></a>");
            var parent2= document.getElementById('linkContainer');
		    document.getElementById('linkContainer').style='display:block; text-align: center;';
		    parent2.setAttribute("class", "col-md-12");
		    parent2.innerHTML="<p><button type='button' class='btn btn-primary' style='font-size: 35px; border-radius: 14px; margin: 20px 0px 40px 0px; width: 400px;' onclick='window.open(\""+results.outputfilename+"\")'>Output file</button></p>"
	    }	
	    if (results.modelfilename != "None"){
            var parent2= document.getElementById('linkContainer');
		    parent2.innerHTML+="<p><button type='button' class='btn btn-primary' style='font-size: 35px; border-radius: 14px; margin: 0px 0px 40px 0px; width: 400px;;' onclick='window.open(\""+results.modelfilename+"\")'>Model file</button></p>"
		    }	

	    if (results.recapfilename != "None"){
            var parent2= document.getElementById('linkContainer');
		    parent2.innerHTML+="<p><button type='button' class='btn btn-primary' style='font-size: 35px; border-radius: 14px; width: 400px;' onclick='force_download(\""+results.recapfilename+"\")'>Experiment Recap file</button></p>"
		    }


	    // y0 stats
	    y0name = labels[1]
	    y0data = results.y0_stats;
	    create_stats_table(y0data, y0name, parent, "y0_stats");
	    
	    // additional y stats
	    //console.log(results)
	    //console.log(labels)
	    if (ny>1){
		    for (i=1; i<ny; i++){
			    
/* 				    if ((plot == "scatter") || (plot == "ml")){ 
				    var node = document.createElement("div");
				    node.setAttribute("class", "col-md-12");
				    node.setAttribute("style", "font-size:20px; font-weight:bold");
				    var num = i+1
				    node.innerHTML="DATASET "+num.toString()
				    parent.appendChild(node)
			    } */
			    
			    name = labels[i+1]
			    data = results[ks[i+1]]
			    
/* 			    if ((plot == "scatter") || (plot == "ml")){

				    xname = labels[0];
				    xdata = results[ks[i+ny]];
    //				console.log(xdata)
				    create_stats_table(xdata, xname, parent, "x_stats"+i);
			    } */
			    create_stats_table(data, name, parent, "y"+i+"_stats");
			    //console.log(name)
			    //console.log(data)
		    }
		    
	    }
	    // Show Stats panel
	    document.getElementById('plot_container').style='display:block;';
	    var statstab = document.getElementById('tab-stats1')
	    var a = statstab.getElementsByTagName("a")[0];
	    if (plot=="stats"){
		    statstab.setAttribute("class", "active")
		    document.getElementById('plot_stats').setAttribute("class", "tab-pane active")
	    }
	    a.innerHTML = stats.charAt(0).toUpperCase() + stats.slice(1)+" Statistics";;

	    // create download stats button
/* 	    var divb = document.createElement("div");
	    divb.setAttribute("class", "col-md-12");
	    divb.setAttribute("style", "margin: 20px 0px; text-align:right");
	    divb.setAttribute("id", "download-btn");
	    parent.appendChild(divb) */
	    
/* 	    var b = document.createElement("button");
	    b.setAttribute("class", "btn btn-primary");
	    b.setAttribute("id", "download_stats");
	    b.setAttribute("onclick", "select_download_dir('store_pdf', 'Statistics', '"+labels+"')");
	    b.innerHTML = "Save Statistics";
	    divb.appendChild(b) */
	    
	    if(plot!="stats"){
		    $('#plot_stats').css('display', 'none');
	    }
	    var modebar = document.getElementsByClassName("modebar")[0]
	    if(typeof modebar != 'undefined'){
		    modebar.style='display:block;';
	    }
	    $("#loader").hide();
/*     }
    catch {
    	alert("Please check model configuration and input features");
    } */
}

/**
 * Creates and appends an HTML table displaying calculated statistical metrics.
 *
 * @param {Object} data Key-value dictionary of statistical metrics.
 * @param {string} name Display title for table header.
 * @param {HTMLElement} parent Parent container element.
 * @param {string} id Target DOM element ID for the container div.
 */
function create_stats_table(data, name, parent, id){
	
		// create stats div
		var node = document.createElement("div");
		node.setAttribute("class", "col-md-6");
		node.setAttribute("id", id);
		node.setAttribute("style", "margin: 20px 0px");
		parent.appendChild(node);
		
		// create table
		var tbl = document.createElement("table");
		tbl.style.width = '100%';
		tbl.setAttribute('border', '1');
		var tbdy = document.createElement('tbody');
		
		// table title
		var tr = document.createElement('tr');
		var td = document.createElement('td');
		td.style.textAlign = "center";
		td.style.fontWeight = "bold";
		td.setAttribute('colSpan', '2')
		td.innerHTML = name;
		tr.appendChild(td)
		tbdy.appendChild(tr);
		//console.log(data)
		// add stats to table
		var x_keys = Object.keys(data);
		var x_values = Object.values(data);
		var n_stats = x_keys.length;
		for (var i = 0; i < n_stats; i++) {
			var tr = document.createElement('tr');
			for (var j = 0; j < 2; j++) {
//			if (i == 2 && j == 1) {
//        break
//      } else {
			var td = document.createElement('td');
			if (j==0){
				td.style.fontWeight = "bold";
				td.innerHTML = x_keys[i].replace("_", " ");
				}
			else{
				if(x_values[i]!="-"){
					td.style.textAlign = "right";
				}
				else
				{
					td.style.textAlign = "center";
				}
				td.innerHTML = x_values[i];
				}
			tr.appendChild(td)
			}
		tbdy.appendChild(tr);
		}
		tbl.appendChild(tbdy);
		node.appendChild(tbl)

}

var csv = {
	width:875,height:1e3, path:"M0,22.261v467.478h512V22.261H0z M155.826,456.348H33.391v-77.913h122.435V456.348z M155.826,345.043H33.391V267.13	h122.435V345.043z M155.826,233.739H33.391v-77.913h122.435V233.739z M322.783,456.348H189.217v-77.913h133.565V456.348z M322.783,345.043H189.217V267.13h133.565V345.043z M322.783,233.739H189.217v-77.913h133.565V233.739z M478.609,456.348H356.174 v-77.913h122.435V456.348z M478.609,345.043H356.174V267.13h122.435V345.043z M478.609,233.739H356.174v-77.913h122.435V233.739z M478.609,122.435H33.391V55.652h445.217V122.435z", transform:"scale(1.8, 1.9)"
};

/**
 * Event handler: Toggles visibility of parameter flagging details and description controls
 * when option radio buttons change state.
 */
$("input[type='radio'][name=optflag]").change(function(){
	$('#description').html('');
	if($(this).val()!="nd")
	{
		populate_flags();
		$("#description").show();
		$("#parflag").show();
		$("#alert-email").show();
	}
	else
	{
		$("#description").hide();
		$("#parflag").hide();
		$("#email-to").val('')
		$("#alert-email").hide();
	}
});

/**
 * Renders an interactive Plotly trend line chart for ML Clustering output.
 *
 * @param {string} pydata Raw JSON string containing output series data.
 * @param {number} ny Number of Y parameters.
 * @param {Array<string>} labels Display label array.
 */
function trend(pydata, ny, labels) {

	fname = get_now_string()
	n_exp = "Trend Analysis"
	display_plot(n_exp)
	var dom = document.getElementById('chartContainer');
	//console.log(pydata)
	var results = JSON.parse(pydata)

	ks = Object.keys(results)
	data = []
	for (var i=1; i<ny+1; i++){
		var curr_y = results[ks[i+1]]
		var curr_x = results.date
		
		var indices =  find_nan(curr_y);
		var final_x = reduce_array(curr_x, indices)
		var final_y = reduce_array(curr_y, indices)
		
		var trace = {
			name : labels[i],
			x: final_x,
			y: final_y,
			mode: 'lines+markers',
			type: 'scattergl',
			line: {shape: 'spline'},
		}
		//console.log(results[ks[i+2]])
		data.push(trace)
	}
	
	

	
	

	
	var layout = {
		xaxis: {
			tickangle : -45
		},
		showlegend : true,
		legend : {
			x : 0,
			y : 1,
			font: {
			family: 'sans-serif',
			size: 12,
			color: '#000'
			},
		bgcolor: '#E2E2E2',
		bordercolor: '#FFFFFF',
		borderwidth: 2
		}
		//title: "Responsive to window's size!",
		//font: {size: 18}
	};
	
	let modeBarButtons = [ 
	[
		{ 
			name: 'Download Plot as Image',
			icon: Plotly.Icons.camera,
			click: function (gd) {
			  Plotly.downloadImage(gd, {
				width: gd._fullLayout.width,
				height: gd._fullLayout.height,
				filename : "trend_"+fname
			  })
			}
		}
	],
	
	
	[
		{ 
			name: 'Save experiment as PDF',
			icon: Plotly.Icons.disk,
			click: function(){
				select_download_dir("store_pdf", n_exp, labels);
				//exportPDF(n_exp, labels);
			}
		}
	], 
	[
		{ 
			name: 'Save results as CSV',
			icon: csv,
			click: function(){

				save_csv(labels, results);
				//exportPDF(n_exp, labels);
			}
		}
	], 
    ["zoom2d", "pan2d", "select2d", "zoomIn2d", "zoomOut2d", "autoScale2d", "resetScale2d",  "toggleSpikelines", "hoverClosestCartesian", "hoverCompareCartesian"]];

	//Plotly.newPlot(dom, data, layout, {responsive:true, editable:true, displaylogo: false, scrollZoom: true, modeBarButtonsToRemove: ['lasso2d'], displayModeBar : true});
	
	
	Plotly.newPlot(dom, data, layout, {responsive:true, editable:true, displaylogo: false, scrollZoom: true, modeBarButtons: modeBarButtons, displayModeBar : true});
	
}

/**
 * Renders an interactive Plotly bar histogram chart.
 *
 * @param {string} pydata Raw JSON string containing input series data.
 * @param {number} ny Number of Y parameters.
 * @param {Array<string>} labels Display label array.
 */
 function histogram(pydata, ny, labels) {
	
	fname = get_now_string()
	n_exp = "Histogram"
	display_plot(n_exp)
	var dom = document.getElementById('chartContainer');
	var binsize = document.getElementById('binsize').value;
	var bintype = $('input[name=bintype]:checked').val();
	var l = labels;
	if(bintype=="binnumber"){
		iswidth = 0
	}
	else
	{
		iswidth = 1
	}	
	var data = []

	$.ajax({
			   method:"POST",
			   url: 'scripts/histogram.py',
			   data:{
				   iswidth : iswidth,
				   y : pydata,
				   b : binsize,
				   ny : ny
			   }
			})
			.done(function(resultdata){
				
				console.log(resultdata)
				for (var i=0; i<ny; i++){
					var counts = resultdata['counts_'+i]
					var bins = resultdata['bins_'+i]

					var intervals = [] //bins intervals
					var x = [] //x coordinate, modified from bins to correctly align bars
					for(var b=0; b<(bins.length-1); b++){
						var end = ")"
						if(b==bins.length-2){
							end = "]"
						}
						intervals.push("["+bins[b]+", "+bins[b+1]+end)
						x.push(bins[b]+(bins[b+1]-bins[b])/2)
					}

					var opac = 1.0
					if(ny>1){opac = 0.6}

					var trace = {
							name : l[i+1],
							x : x,
							
							hovertemplate: '<b>Counts</b>: %{y}' +
							'<br><b>Interval</b>: %{text}<br>'+
							"<extra></extra>",
							text : intervals,
							y : counts,
							type : 'bar',
							marker: {
								opacity: opac,
								line: {
								  width: 1.5
								}
							}

					}
				data.push(trace) 
				}
				
				var layout = {
					barmode: 'overlay',
					bargap : 0,
					hovermode: 'closest',
					showlegend : true,
					legend : {
						x : 0,
						y : 1,
						font: {
						family: 'sans-serif',
						size: 12,
						color: '#000'
						},
					bgcolor: '#E2E2E2',
					bordercolor: '#FFFFFF',
					borderwidth: 2
					}

				};
				
					let modeBarButtons = [ 
				[
					{ 
						name: 'Download Plot as Image',
						icon: Plotly.Icons.camera,
						click: function (gd) {
						  Plotly.downloadImage(gd, {
							width: gd._fullLayout.width,
							height: gd._fullLayout.height,
							filename : "histogram_"+fname
						  })
						}
					}
				],
				
				
				[
					{ 
						name: 'Save experiment as PDF',
						icon: Plotly.Icons.disk,
						click: function(){
							
							select_download_dir("store_pdf", n_exp, labels);
						}
					}
				], 
				[
					{ 
						name: 'Save results as CSV',
						icon: csv,
						click: function(){

							save_csv(labels, JSON.parse(pydata));
							//exportPDF(n_exp, labels);
						}
					}
				], 
				["zoom2d", "pan2d", "select2d", "zoomIn2d", "zoomOut2d", "autoScale2d", "resetScale2d",  "toggleSpikelines", "hoverClosestCartesian", "hoverCompareCartesian"]];

				console.log(data)
				
				Plotly.newPlot(dom, data, layout, {responsive:true, editable:true, displaylogo: false, scrollZoom: true, modeBarButtons: modeBarButtons, displayModeBar : true});
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		})
	
	
		
	
	
	
	
	
/* 	var results = JSON.parse(pydata)

	ks = Object.keys(results)
	
	

	
	
	for (var i=1; i<ny+1; i++){
		var curr_y = results[ks[i+1]]
		var indices =  find_nan(curr_y); */
		//var final_y = reduce_array(curr_y, indices)	
			//change from bin number to binsize if required
		/*var numy=final_y.map(Number)
		var miny=Math.min(...numy)
		var maxy=Math.max(...numy)
		var miny=Math.min(...final_y)
		var maxy=Math.max(...final_y)*/
		


		

		

	
/* 	var layout = {
		showlegend : true,
		legend : {
			x : 0,
			y : 1,
			font: {
			family: 'sans-serif',
			size: 12,
			color: '#000'
			},
		bgcolor: '#E2E2E2',
		bordercolor: '#FFFFFF',
		borderwidth: 2
		}
		//title: "Responsive to window's size!",
		//font: {size: 18}
	};
	
		let modeBarButtons = [ 
	[
		{ 
			name: 'Download Plot as Image',
			icon: Plotly.Icons.camera,
			click: function (gd) {
			  Plotly.downloadImage(gd, {
				width: gd._fullLayout.width,
				height: gd._fullLayout.height,
				filename : "histogram_"+fname
			  })
			}
		}
	],
	
	
	[
		{ 
			name: 'Save experiment as PDF',
			icon: Plotly.Icons.disk,
			click: function(){
				
				select_download_dir("store_pdf", n_exp, labels);
			}
		}
	], 
	[
		{ 
			name: 'Save results as CSV',
			icon: csv,
			click: function(){

				save_csv(labels, results);
				//exportPDF(n_exp, labels);
			}
		}
	], 
	["zoom2d", "pan2d", "select2d", "zoomIn2d", "zoomOut2d", "autoScale2d", "resetScale2d",  "toggleSpikelines", "hoverClosestCartesian", "hoverCompareCartesian"]];

	console.log(data)
	
	Plotly.newPlot(dom, data, layout, {responsive:true, editable:true, displaylogo: false, scrollZoom: true, modeBarButtons: modeBarButtons, displayModeBar : true}); */
}	

/**
 * Renders an interactive Plotly scatter plot chart for ML predictions/ground truth.
 *
 * @param {string} pydata Raw JSON string containing X/Y series data.
 * @param {number} ny Number of Y parameters.
 * @param {Array<string>} labels Display label array.
 */
function scatterplot(pydata, ny, labels) {
	
	fname = get_now_string()
	n_exp = "Scatter Plot"
	display_plot(n_exp)

	var dom = document.getElementById('chartContainer');
	var results = JSON.parse(pydata)

	ks = Object.keys(results) 	
	var idx = find_nan(results.x);
	
	data = []

	for (var i=0; i<ny; i++){
		var curr_x = results.x.slice();
		var curr_y = results[ks[i+2]]

		var idy =  find_nan(curr_y);
		var indices = idy.concat(idx)
		
		//console.log(indices)
		var final_x = reduce_array(curr_x, indices)
		var final_y = reduce_array(curr_y, indices)



		var trace = {
			name : labels[i+1],
			x: final_x,
			y: final_y,
			mode: 'markers',
			type: 'scattergl',
			text: results.date
			
		}
		//console.log(results[ks[i+2]])
		data.push(trace)
	}
	
	var layout = {
		showlegend : true,
		legend : {
			x : 0,
			y : 1,
			font: {
			family: 'sans-serif',
			size: 12,
			color: '#000'
			},
		bgcolor: '#E2E2E2',
		bordercolor: '#FFFFFF',
		borderwidth: 2
		}
		//title: "Responsive to window's size!",
		//font: {size: 18}
	};
	
		let modeBarButtons = [ 
	[
		{ 
			name: 'Download Plot as Image',
			icon: Plotly.Icons.camera,
			click: function (gd) {
			  Plotly.downloadImage(gd, {
				width: gd._fullLayout.width,
				height: gd._fullLayout.height,
				filename : "scatter_"+fname
			  })
			}
		}
	],
	
	
	[
		{ 
			name: 'Save experiment as PDF',
			icon: Plotly.Icons.disk,
			click: function(){
				
				select_download_dir("store_pdf", n_exp, labels);
			}
		}
	], 
	[
		{ 
			name: 'Save results as CSV',
			icon: csv,
			click: function(){

				save_csv(labels, results);
				//exportPDF(n_exp, labels);
			}
		}
	], 
	["zoom2d", "pan2d", "select2d", "zoomIn2d", "zoomOut2d", "autoScale2d", "resetScale2d",  "toggleSpikelines", "hoverClosestCartesian", "hoverCompareCartesian"]];

	//Plotly.newPlot(dom, data, layout, {responsive:true, editable:true, displaylogo: false, scrollZoom: true, modeBarButtonsToRemove: ['lasso2d'], displayModeBar : true});
	
	
	Plotly.newPlot(dom, data, layout, {responsive:true, editable:true, displaylogo: false, scrollZoom: true, modeBarButtons: modeBarButtons, displayModeBar : true});
	

}

/**
 * Enables advanced statistical options in UI.
 */
function set_advanced_stats(){
	document.getElementById("stats_enable").value="advanced";
	document.getElementById("stats").style="display : block";
	document.getElementById("global_a").style="display : inline-block";
	document.getElementById("advanced_a").style="display : none";
}

/**
 * Reverts statistical options in UI to global default.
 */
function set_global_stats(){
	document.getElementById("stats_enable").value="global"
	document.getElementById("stats").style="display : none";
	document.getElementById("advanced_a").style="display : inline-block";
	document.getElementById("global_a").style="display : none";
	
}

/**
 * Array filter callback to remove duplicate items.
 *
 * @param {*} value Current array element.
 * @param {number} index Current element index.
 * @param {Array} self Array reference.
 * @returns {boolean} True if first occurrence of element.
 */
function only_unique(value, index, self) { 
    return self.indexOf(value) === index;
}

/**
 * Finds array indices containing sentinel invalid/NaN values (-999 or -999.0).
 *
 * @param {Array} in1 Input data array.
 * @returns {Array<number>} Array of indices containing invalid values.
 */
function find_nan(in1){
	var indices = [];
	var x = in1;
	var el1 = -999;
	var idx1 = x.indexOf(el1);
	while (idx1 != -1) {
		indices.push(idx1);
		idx1 = x.indexOf(el1, idx1 + 1);
	}

	var el2 = -999.0;
	var idx2 = x.indexOf(el2);
	while (idx2 != -1) {
		indices.push(idx2);
		idx2 = x.indexOf(el2, idx2 + 1);
	}
	return indices
}

/**
 * Removes elements at specified indices from an array.
 *
 * @param {Array} arr Source data array.
 * @param {Array<number>} indices Array of indices to exclude.
 * @returns {Array} Filtered clean data array.
 */
function reduce_array(arr, indices){
	var new_arr = [...arr]
	for (var j=0; j<indices.length; j++){
			delete new_arr[indices[j]]
		}		
	
	
	new_arr = new_arr.filter(function (el) {
		return el != null;
	});
	
	return new_arr
}

/**
 * Generates formatted UTC timestamp string for output file naming.
 *
 * @returns {string} Formatted timestamp string.
 */
function get_now_string(){
	
	var date = get_utc_date()
	var curr_date = new Date(date).toISOString();
	
	curr_date = curr_date.split(".")[0];
	var new_date = curr_date.replace(/-/g,"").replace(/:/g,"");
	
	return new_date
}

/**
 * Tab switch callback: shows main plot/chart container tab.
 */
function onclick_plot(){
	$('#form-div').css('display', 'block');
	$('#plot_stats').css('display', 'none');
	$('#plot_files').css('display', 'none');
	$('#custom_plot').css('display', 'block');
	var dom = document.getElementById('chartContainer');
	
	Plotly.relayout( dom, {
		'xaxis.autorange': true,
		'yaxis.autorange': true
	});  
}  

/**
 * Tab switch callback: shows exported files container tab.
 */
function onclick_files(){

  $('#form-div').css('display', 'none'); 
  $('#plot_files').css('display', 'block'); 
  //$('#plot_files').css('flex-wrap', 'wrap');
  $('#plot_stats').css('display', 'none')
  $('#custom_plot').css('display', 'none');

$('#files_tbl').DataTable().columns.adjust().draw()
  $('#plot_files').css('display', 'flex'); 
  $('#plot_files').css('flex-wrap', 'wrap');	 
} 

/**
 * Tab switch callback: shows statistical analysis results tab.
 */
function onclick_stats(){
  var t = document.getElementById("plot_type").value
  if(t != "stats"){
    $('#form-div').css('display', 'none');
    
/*    if(t=="upload"){
      	console.log($("#op").val())
    	if($("#op").val()!="stats"){$('#plot_stats').removeClass('active');}
    }*/
  }
  else{
    $('#form-div').css('display', 'block');
    $('#plot_tab').removeClass('active');
  }
  $('#plot_stats').css('display', 'flex'); 
  $('#plot_stats').css('flex-wrap', 'wrap'); 
  $('#plot_files').css('display', 'none');
  $('#custom_plot').css('display', 'none');   
} 

/**
 * Fetches available Machine Learning models for a chosen technique via AJAX.
 *
 * @param {string} ml Selected Machine Learning technique ('classifier', 'cluster', 'regressor').
 */
function populate_ml(ml){
	//console.log(ml)
	$.ajax({
			   method:"POST",
			   url: 'scripts/listMlModels.py',
			   data:{
				   ml_type : ml
			   }
			})
			.success(function(resultdata){
				error = resultdata["error"]
				if(error==1){
					out = '<label class="col-md-2 control-label">Machine Learning Model</label><p>'+resultdata["out"]+'</p>'
				}
				else{
					//console.log(resultdata["out"])
					out = '<label class="col-md-2 control-label">Machine Learning Model</label><select name="model" id="model">'
					for (var i=0; i<resultdata["out"].length; i++){
/* 						var option = document.createElement("option");
option.text = "Text";
option.value = "myvalue";
var select = document.getElementById("id-to-my-select-box");
select.appendChild(option); */
						out += '<option value="'+resultdata["out"][i]+'">'+resultdata["out"][i]+'</option>'
					}
					out+='</select>'
					
					out+='<button class="btn btn-primary" formaction="modelHelp.php" id="submit_button" formtarget="_blank" style="margin-left: 5px;">Help</button>'
					$('#submit_button').show();
					$('#ml_model_div').html(out)
					$('#ml_model_div').show();
				}
				
			})

}

/**
 * Triggers browser download for a target file URL.
 *
 * @param {string} url Target resource URL.
 */
function force_download(url) {
  const a = document.createElement('a')
  a.href = url
  a.download = url.split('/').pop()
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}