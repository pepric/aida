#!/usr/bin/python

"""
Email Notification Dispatcher.

This module provides the Email class to construct and send formatted 
HTML notification emails for report completions, plot generations, 
flagged items, and execution errors.

@package AIDA
@module send_mail
"""

import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import socket
import functions as util

class Email():
    """Construct and dispatch HTML notification emails using SMTP credentials.

    Parameters
    ----------
    smtpfile : str
        File path to SMTP server credentials JSON configuration.

    Attributes
    ----------
    host : str
        SMTP host address.
    port : int or str
        SMTP server port.
    user : str
        SMTP authentication username.
    pwd : str
        SMTP authentication password.
    """
    def __init__(self, smtpfile):
        smtpconf = self.get_smtp_data(smtpfile)
        if smtpconf['host'] != "":
            self.host = smtpconf['host']
            self.port = smtpconf['port']
            self.user = smtpconf['user']
            self.pwd = smtpconf['password']
        else:
            #Error
            pass

    def error_img_text(self, maildata, error = "N/A"):
        """Construct HTML email body for failed image analysis operations.

        Parameters
        ----------
        maildata : list
            Metadata list containing operation, source system, and file list.
        error : str, optional
            Detailed error message string (default is "N/A").

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """       
        
        text = """\
    <html>
      <body>
        <p>The generation of requested analysis by AIDA is failed:</p>
        <p>
        Experiment : Statistics on """+str(maildata[0]).upper()+""" images<br/>
        Source : """+maildata[1]+"""<br/>
        Involved Files : """+maildata[5][1:-1]+"""<br/>"""
        
        text +="""  
      
        
        </p>
        <p style="font-weight:bold; font-decoration:underline">Error : """+error+"""
        <br/>
        <p><span>Please, contact AIDA admin to report the error</span></p>
      </body>
    </html>
    """
        return text

    def error_plot_text(self, maildata, error = "N/A"):
        """Construct HTML email body for failed plot generation jobs.

        Parameters
        ----------
        maildata : list
            Metadata list containing plot name, data origin, system, parameters,
            datetime range, and statistical functions.
        error : str, optional
            Detailed error message string (default is "N/A").

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """         
        
        text = """\
    <html>
      <body>
        <p>The generation of requested plot by AIDA is failed:</p>
        <p>
        Experiment : """+str(maildata[0])+"""<br/>
        Data Origin : """+maildata[1].upper()+""" - """+maildata[2]+"""<br/>"""
        
        if maildata[3][0]!="None":
            text += """X Parameter: """+maildata[3][0]+"""<br/>"""
        pars = maildata[3][1:]
        p_text = ",".join(pars)     
        text += """Y Parameter(s) : """+p_text+"""<br/>"""        
        text += """        
        Date Range : """+maildata[4]+""" - """+maildata[5]+"""<br/>"""
        
        stats = maildata[6]
        if len(stats) > 0:
            slist = str(maildata[6].keys())
            s = slist.replace("'","").replace("dict_keys([","").replace("])","").replace("_"," ")
        else:
            s = "None"
        
        text +="""  
        Statistics : """+s+"""<br/>        
        
        </p>
        <p style="font-weight:bold; font-decoration:underline">Error : """+error+"""
        <br/>
        <p><span>Please, contact AIDA admin to report the error</span></p>
      </body>
    </html>
    """
        return text
      
    def error_report_text(self, maildata, period, error = "N/A"):
        """Construct HTML email body for failed report generation jobs.

        Parameters
        ----------
        maildata : list
            Metadata list containing config file name, dates, and run ID.
        period : str
            Report periodicity mode name.
        error : str, optional
            Detailed error message string (default is "N/A").

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """         
        
        text = """\
    <html>
      <body>
        <p>The generation of report by AIDA is failed:</p>
        <p style="font-weight:bold; font-decoration:underline">SUMMARY</p>
        <p>
        Run ID : """+str(maildata[4])+"""<br/>
        Type : """+period+"""<br/>
        Configuration File : """+maildata[0]+"""<br/>
        Date Range : """+maildata[1]+""" - """+maildata[2]+"""

        </p>
        <br/>
        <p><span style="font-weight:bold;">Encountered error: </span>"""+error+"""      
        </p>
      </body>
    </html>
    """
        return text        
          
    def get_smtp_data(self, smtpfile):
        """Read and parse SMTP server configuration parameters from file.

        Parameters
        ----------
        smtpfile : str
            File path to SMTP configuration file.

        Returns
        -------
        mailconfig : dict
            Parsed SMTP configuration dictionary.
        """        
        try:
            # get report config data from json
            fileobj = open(smtpfile, "r")
            jsonstr = fileobj.read()
            fileobj.close()
            #convert input string to json object
            mailconfig = json.loads(jsonstr)
        except:
            mailconfig = {"host" : ""}
            
        return mailconfig

    def ok_report_flagged(self, maildata, filename="", etype="plot"):
        """Construct HTML email body for successfully flagged report items.

        Parameters
        ----------
        maildata : list
            Metadata list containing username, status, and comments.
        filename : str, optional
            Report filename string (default is "").
        etype : str, optional
            Experiment type string (default is "plot").

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """         
        user = maildata[0]
        status = maildata[1].upper()
        comment_exp = maildata[2]
        text = """\
        <html>
            <body>
                <p>A new """+etype+""" has been flagged in AIDA repository by user """+user+""".</p>
                <p>For additional info, please contact """+user+""" directly.</p>
                <br/>"""
        if filename != "":
            text +="""<b>Report Name :</b> """+filename+"""<br/>"""
        text +="""<p><b>Status:</b> """+status+"""<br/>"""

        if isinstance(comment_exp, str):
            text +="""<b>Comments :</b> """+comment_exp+"""<br/>"""
        elif isinstance(comment_exp, dict):
            for k in comment_exp:
                text +="""<b>Comment on """+k+""" :</b> """+comment_exp[k]+"""<br/>"""
                
        text+="""</p></body></html>"""
        return text      
      
    def ok_flagged(self, maildata, filename="", etype="plot"):
        """Construct HTML email body for successfully flagged and stored experiments.

        Parameters
        ----------
        maildata : list
            Metadata list containing username, archive name, system, status, and comments.
        filename : str, optional
            Experiment filename string (default is "").
        etype : str, optional
            Experiment type string (default is "plot").

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """         
        user = maildata[0]
        save = maildata[1].upper()
        source = maildata[2].upper()
        status = maildata[3].upper()
        comment_exp = maildata[4]
        text = """\
        <html>
            <body>
                <p>A new """+etype+""" has been flagged and stored in AIDA repository by user """+user+""". It has been stored in the """+save+""" archive.</p>
                <p>For additional info, please contact """+user+""" directly.</p>
                <br/>"""
        if filename != "":
            text +="""<b>Filename :</b> """+filename+"""<br/>"""
        text +="""<p><b>System:</b> """+source+"""<br/>
                <b>Status:</b> """+status+"""<br/>"""

        if isinstance(comment_exp, str):
            text +="""<b>Comments :</b> """+comment_exp+"""<br/>"""
        elif isinstance(comment_exp, dict):
            for k in comment_exp:
                text +="""<b>Comment on """+k+""" :</b> """+comment_exp[k]+"""<br/>"""
                
        text+="""</p></body></html>"""
        return text

    def ok_img_text(self, maildata, plotid, source):
        """Construct HTML email body for successful image analysis jobs.

        Parameters
        ----------
        maildata : list
            Metadata list containing operation, files, and host URL.
        plotid : int or str
            Database record ID for the generated analysis results.
        source : str
            System data source name.

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """         
        webappdir = util.repConfig().data['webapp_dir']    
        ploturl = "http://"+maildata[4]+"/"+webappdir+"/view_results.php?id="+str(plotid)+"&s="+source        
        
        text = """\
    <html>
      <body>
        <p>A new image analysis has been performed by AIDA:</p>
        <p style="font-weight:bold; font-decoration:underline">SUMMARY</p>
        <p>
        Experiment : Statistics on """+str(maildata[0]).upper()+""" images<br/>
        Source : """+source+"""<br/>
        Involved Files : """+maildata[5][1:-1]+"""<br/>"""
        
        text +="""
        </p>
        
        <p>Click <a href='"""+ploturl+"""'>here</a>  to view results.</p>
      </body>
    </html>
    """
        return text

    def ok_ml_text(self, maildata, plotid, source):
        """Construct HTML email body for successful Machine Learning experiments.

        Parameters
        ----------
        maildata : list
            Metadata list containing experiment title, technology, model, origin,
            labels, features, date range, and URL.
        plotid : int or str
            Database record ID for the generated ML experiment.
        source : str
            System data source name.

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """
        
        webappdir = util.repConfig().data['webapp_dir']    
        ploturl = "http://"+maildata[7]+"/"+webappdir+"/view_plot.php?id="+str(plotid)+"&s="+source+"&exp=ml"
        
        text = """\
    <html>
      <body>
        <p>A new data analysis has been performed by AIDA:</p>
        <p style="font-weight:bold; font-decoration:underline">SUMMARY</p>
        <p>
        Experiment : """+str(maildata[0])+"""<br/>
        Learning Technology : """+str(maildata[8])+"""<br/>
        Model : """+str(maildata[9])+"""<br/>
        Data Origin : """+maildata[2]+"""<br/>"""
        
        if maildata[3][0]!="None" and maildata[3][0]!="undefined.undefined":
            text += """Label: """+maildata[3][0]+"""<br/>"""
        pars = maildata[3][1:]
        p_text = ",".join(pars)     
        text += """Features : """+p_text+"""<br/>"""        
        
        text += """        
        Date Range : """+maildata[4]+""" - """+maildata[5]+"""<br/></p>
        
        <p>Click <a href='"""+ploturl+"""'>here</a>  to view results.</p>
      </body>
    </html>
    """
        return text
      
    def ok_plot_text(self, maildata, plotid, source):
        """Construct HTML email body for successful offline plot generation jobs.

        Parameters
        ----------
        maildata : list
            Metadata list containing experiment name, origin, system, parameters,
            date range, statistics, and URL.
        plotid : int or str
            Database record ID for the generated plot.
        source : str
            System data source name.

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """
        
        webappdir = util.repConfig().data['webapp_dir']    
        ploturl = "http://"+maildata[7]+"/"+webappdir+"/view_plot.php?id="+str(plotid)+"&s="+source        
        
        text = """\
    <html>
      <body>
        <p>A new data analysis has been performed by AIDA:</p>
        <p style="font-weight:bold; font-decoration:underline">SUMMARY</p>
        <p>
        Experiment : """+str(maildata[0])+"""<br/>
        Data Origin : """+maildata[1].upper()+""" - """+maildata[2]+"""<br/>"""
        
        if maildata[3][0]!="None":
            text += """X Parameter: """+maildata[3][0]+"""<br/>"""
        pars = maildata[3][1:]
        p_text = ",".join(pars)     
        text += """Y Parameter(s) : """+p_text+"""<br/>"""        
        
        
        text += """        
        Date Range : """+maildata[4]+""" - """+maildata[5]+"""<br/>"""
        
        stats = maildata[6]
        if len(stats) > 0:
            slist = str(maildata[6].keys())
            s = slist.replace("'","").replace("dict_keys([","").replace("])","").replace("_"," ")
        else:
            s = "None"
        
        text +="""  
        Statistics : """+s+"""<br/>        
        
        </p>
        
        <p>Click <a href='"""+ploturl+"""'>here</a>  to view results.</p>
      </body>
    </html>
    """
        return text
      
    def ok_report_text(self, maildata, period, fullfile, pdf_ok):
        """Construct HTML email body for successful report generation jobs.

        Parameters
        ----------
        maildata : list
            Metadata list containing run ID, user, creation date, and date range.
        period : str
            Report periodicity mode name.
        fullfile : str
            Base download URL path to generated report files.
        pdf_ok : bool
            Flag indicating whether PDF version was generated successfully.

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """        
        
        if pdf_ok:
            p_pdf = """<p>Click <a href='"""+fullfile+""".pdf' download='"""+fullfile+""".pdf'>here</a>  to download it in PDF version or visit AIDA portal to list available reports</p>"""       
        else:
            p_pdf = """PDF version is not available. Contact AIDA admin for further info."""
        
        text = """\
    <html>
      <body>
        <p>A new report has been generated by AIDA:</p>
        <p style="font-weight:bold; font-decoration:underline">SUMMARY</p>
        <p>
        Run ID : """+str(maildata[6])+"""<br/>
        Type : """+period+"""<br/>
        Report File Name : """+maildata[0]+"""<br/>
        Creation Date : """+maildata[2]+"""<br/>
        Owner : """+maildata[1]+"""<br/>
        Date Range : """+maildata[4]+""" - """+maildata[5]+"""
        
        
        </p>
      
        <p>Click <a href='"""+fullfile+""".xml' download='"""+fullfile+""".xml'>here</a>  to download it in XML version or visit AIDA portal to list available reports</p>"""+p_pdf+"""
     
      </body>
    </html>
    """
        return text
      
    def send_mail(self, message):
        """Connect to SMTP server and dispatch compiled MIME email message.

        Parameters
        ----------
        message : MIMEMultipart
            Compiled MIME email message object containing headers and HTML body.
        """         
        
        if self.port==465:
            server=smtplib.SMTP_SSL(self.host, self.port)
        else:
            server = smtplib.SMTP(self.host, self.port)
            server.ehlo()
            server.starttls()
        if self.pwd != "":        
            server.login(self.user, self.pwd)

        TO = [message['To']]
        CC = message["CC"].split(",")                             
        server.sendmail(self.user, TO+CC, message.as_string())
        server.quit()      
      
    def set_message(self, subject, fromuser, touser, text, cc=""):
        """Construct MIMEMultipart email message object with headers and HTML body.

        Parameters
        ----------
        subject : str
            Email subject line.
        fromuser : str
            Sender display name or email address.
        touser : str
            Primary recipient email address.
        text : str
            HTML content body string.
        cc : str or list of str, optional
            Carbon copy recipient email address(es) (default is "").

        Returns
        -------
        message : MIMEMultipart
            Compiled MIME message object ready for dispatch.
        """         
        message = MIMEMultipart("alternative")
        message['Subject'] = subject
        message["From"] = fromuser
        message["To"] = touser
        if isinstance(cc,list):
            message["CC"] = ",".join(cc)
        else:
            message["CC"] = cc                            
        part = MIMEText(text, "html")   
        message.attach(part)
        
        return message
        
    def stop_report_text(self, user, errorlist, runid):
        """Construct HTML email body when a report generation job is manually stopped.

        Parameters
        ----------
        user : str
            Username who initiated the stop action.
        errorlist : dict
            Error and warning diagnostic summary dictionary.
        runid : int or str
            Report experiment run ID.

        Returns
        -------
        text : str
            Formatted HTML email body content string.
        """        
        
        text = """\
    <html>
      <body>
        <p>Report generation with RUNID = """+str(runid)+""" has been stopped by """+user+""".</p>"""
        if errorlist['error'] == 2:        
            text += """<p style="font-weight:bold; font-decoration:underline">WARNINGS</p>
    <p>"""+errorlist['msg']+"""</p>"""
      
        text += """<p>For further info, please contact """+user+"""</p>
     
      </body>
    </html>
    """
        return text        
        