<?php
/**
 * Plot Data Selection and Setup View.
 *
 * Page template for configuring and launching interactive plots (trend, scatter, histogram, statistics).
 * Captures query string parameters for plot type and data source, populates enabled system options,
 * renders date range pickers, and initializes advanced statistical tool choices.
 *
 * @package    AIDA
 * @subpackage Views\Plots
 * @author     Giuseppe Riccio
 * @version    1.1.0
 */
 ?>
<!doctype html>
<html class="fixed">
	<?php
		include('functions.php');
		/**
		 * Parse query string parameters for plot rendering.
		 *
		 * @var string $plot  Target plot type identifier (e.g., 'trend', 'scatter', 'histogram').
		 * @var string $title Computed page title string returned by get_plot_title().
		 */		
  		$plot = $_GET['plot'];
  		$title = get_plot_title($plot);
		include("header.php"); 
  	?>
  		
		<!-- start: page -->
		<?php include("plotcontainer.php"); ?>
		<div class="row">
			<div class="col-xs-12" id = "form-div">
				<section class="panel">
					<header class="panel-heading">
						<div class="panel-actions">
							<a href="#" class="fa fa-caret-down"></a>
							<a href="#" class="fa fa-times"></a>
						</div>
						<h2 class="panel-title">Select Data to Plot</h2>
					</header>
					<div class="panel-body">
						<form id="detector_form" class="form-horizontal form-bordered" method="" action="" novalidate = "novalidate">
							<div class="form-group">
								<label class="col-md-2 control-label">Data source</label>
								<div class="col-md-6">
									<select name="hktm_source" id="hktm_source" class="form-control" required>
										<option value="" disabled selected>Select Data source</option>
										<?php 
											populate_dropdown("systems", "name", "enabled=1 AND origin='".$_GET['s']."'");
										?>
									</select>
								</div>
							</div>
							<div class="form-group" id="daterange" style="display:none; float:left">
								<label class="col-md-2 control-label">Date range (UTC)</label>
								<div class="col-md-8">
									<div class='input-daterange input-group date' >
										<span class="input-group-addon" id="dateiconstart">
											<span class="glyphicon glyphicon-calendar"></span>
										</span>
										<input type='text' class="form-control indate" name="tstart" id="tstart" required />
									</div>
									<div class='input-daterange input-group date' >
										<span class="input-group-addon" id="dateiconend">
											<span class="glyphicon glyphicon-calendar"></span>
										</span>
										<input type='text' class="form-control indate" name="tend" id="tend" required />
									</div>
								</div>
							</div>
							<div class="form-group" id="hidden-fields">
								<input type="hidden" name="det-type" id = "det-type" value="None"></input>
								<input type="hidden" name="n_ypar" id = "n_ypar" value=1></input>
								<input type="hidden" name="plot_type" id = "plot_type" value="<?php echo $_GET['plot']; ?>" disabled></input>
								<input type="hidden" name="stats_enable" id = "stats_enable" value="global" disabled></input>
								<input type="hidden" name="stats_list" id = "stats_list" value=""></input>
								<input type="hidden" name="usecase" id = "usecase" value="<?php echo $_GET['s']; ?>" disabled></input>
								<span id="plotdata" ></span>
							</div>
						</form>


						<form id="stats_form" class="form-horizontal form-bordered" method="" action="">
							<div class="form-group" id="stats" style="display:none;">
								<label class="col-md-2 control-label">Statistical Tools</label>
								<div class="stat-list col-md-6">
									<input type="checkbox" id="checkThemAll">Select/Deselect All</input>
									<?php populate_stats();?>
								</div>
							</div>
						</form>
						<div class="col-md-12" style="text-align:right">
							<button class="btn btn-primary" id="advanced_a" onclick="set_advanced_stats()">Advanced Statistics</button>
							<button class="btn btn-primary"  id="global_a" style="display:none" onclick="set_global_stats()">Default Statistics</button>
							<button class="btn btn-primary" id = "submit_button" >Submit</button>
							<button type="reset" class="btn btn-default" onClick="window.location.reload();">Reset</button>
						</div>
					</div>
				</section>
			</div>
		</div>

		<?php include("loader.html"); ?>
		<canvas id="canvas"></canvas>
		<div id="plot_img" style="display:none"><img id = "png_img"></img></div>
			<!--<button class="btn btn-default" onClick="prova()">Marker to Red</button>-->
			<?php include("modalbox.php"); show_modal("exp");?>
	</section>
						


	<?php include("footer.php"); ?>
	<?php include("base_scripts.html"); ?>
	<?php include("form_scripts.html"); ?>	
	<script src="assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
	<script src="assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
	<!--<script src="assets/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>-->
	<script src="assets/vendor/DataTables/datatables.min.js"></script>

	<!-- IOT -->
	<script src="assets/javascripts/lsst/plots.js"></script>
	<script src="assets/javascripts/lsst/plots_utils.js"></script>
	<script src="assets/javascripts/lsst/forms.js"></script>	
	<!-- Validation -->
	<script src="assets/javascripts/lsst/validation.js"></script>
	
	<!-- Theme Base, Components and Settings -->
	<script src="assets/javascripts/theme.js"></script>
	
	<!-- Theme Custom -->
	<script src="assets/javascripts/theme.custom.js"></script>
	
	<!-- Theme Initialization Files -->
	<script src="assets/javascripts/theme.init.js"></script>
	
	<script src="assets/javascripts/lsst/jqscripts.js"></script>

</html>
</body>