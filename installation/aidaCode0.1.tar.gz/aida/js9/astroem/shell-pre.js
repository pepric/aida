
// astroem.js: astronomy/astrophysics utilities compiled to javascript
// see: https://github.com/kripken/emscripten
