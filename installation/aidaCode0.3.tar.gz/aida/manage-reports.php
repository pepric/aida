<!doctype html>
<html class="fixed">
	<?php 
		$title = "Reports Handling";
		include("header.php"); ?>
			<!-- start: page -->
			<div class="row">
				<div class="col-xs-12" style="text-align:center">
					<img src="images/under_construction.png" alt="Work in progress">
				</div>
			</div>
		</section>
	<?php include("footer.php"); ?>
	
	<script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>

</html>